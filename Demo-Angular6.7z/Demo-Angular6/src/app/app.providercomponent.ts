import { Component } from "@angular/core";

import { JobPortalService } from "./jobportalservice";
import { FormControl, FormGroup } from "@angular/forms";
import { Validators,FormBuilder} from '@angular/forms';


@Component({
    selector:'add-prov',
    templateUrl:'app.jobprovider.html'
})
export class AddProvider{
    model:any={};
    msg:string="Provider added successfully..";
    prov=this.fb.group({
        name :  ['',Validators.required],
        email : ['',Validators.required],
    });   
     
    constructor(private service:JobPortalService,private fb: FormBuilder){}
    

    addProvider(){
        this.model.name=this.prov.value.name;
        this.model.email=this.prov.value.email;
        this.service.addAllProvider(this.model).
        subscribe((data:any)=>console.log(data));

        alert("Provider Added Successfully!!");
    }

    
}