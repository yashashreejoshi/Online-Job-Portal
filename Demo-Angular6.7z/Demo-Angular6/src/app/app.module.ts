﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import {Routes,RouterModule} from '@angular/router';
//import { AddProvider } from './app.providercomponent';
import { AddJobSeeker } from './app.seekercomponent';
import { AddJobApplication } from './app.jobapplicationcomponent';
import { SearchByDescription } from './app.searchbydescomponent';
import { AddProvider } from './app.providercomponent';
import { AddJob } from './app.jobcomponent';
import { SearchByCity } from './app.searchbycitycomponent';
import { JobSideBar } from './app.sidebar';
import { JobHeader } from './app.header';
import { JobCenter } from './app.center';
import { ReactiveFormsModule } from '@angular/forms';


const route:Routes=[
    {path:"addProvider",component:AddProvider},
    {path:"addJob",component:AddJob},
    {path:"addSeeker",component:AddJobSeeker},
    {path:"addApplication",component:AddJobApplication},
    {path:"searchByDescription",component:SearchByDescription},
    {path:"searchByCity",component:SearchByCity} 
    ];

@NgModule({
    imports: [
        BrowserModule,HttpClientModule,FormsModule,RouterModule.forRoot(route) ,ReactiveFormsModule 
    ],
    declarations: [
        AppComponent,AddProvider,AddJob,AddJobSeeker,AddJobApplication,SearchByDescription,SearchByCity,JobSideBar,JobHeader,JobCenter
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }