import { Component } from "@angular/core";

@Component({
    selector:'center-job',
    templateUrl:'app.center.html'
})
export class JobCenter{

}