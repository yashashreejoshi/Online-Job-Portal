
import { Component } from "@angular/core";

import { JobPortalService } from "./jobportalservice";
import { FormGroup, FormControl } from "@angular/forms";


@Component({
    selector:'add-apply',
    templateUrl:'app.jobapplication.html'
})
export class AddJobApplication{
    apply =new FormGroup({
        seeker : new FormControl(''),
        job : new FormControl(''),
    }); 
    constructor(private service:JobPortalService){}
    model:any={};

    addApplication(){
        console.log(this.model);
        this.service.addAllApplication(this.model).
        subscribe((data:any)=>console.log(data));
        alert("You Have Applied To Job Successfully!!");
}
    }
    