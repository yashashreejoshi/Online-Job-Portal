import { JobSeeker } from "./app.jobseeker";
import { Job } from "./app.job";

export class JobApplication {

    id:number;
    date:Date;
   jobSeeker:JobSeeker;
   job:Job;
}