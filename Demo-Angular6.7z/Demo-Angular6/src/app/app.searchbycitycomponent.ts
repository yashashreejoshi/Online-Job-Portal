
import { Component } from "@angular/core";
import { Job } from "./app.job";
import { JobPortalService } from "./jobportalservice";
import { FormGroup, FormControl } from "@angular/forms";


@Component({
    selector:'search-city',
    templateUrl:'app.searchbycity.html'
})
export class SearchByCity{
searchC =new FormGroup({
    city : new FormControl(''),
});   
    constructor(private service:JobPortalService){}
    job:Job[];
city:string;

    searchByCity(){
        console.log(this.service.searchJobsByCity(this.city).subscribe((data:any)=>console.log(this.job=data)));
       }
}