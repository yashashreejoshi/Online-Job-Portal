
import { Component } from "@angular/core";
import { Job } from "./app.job";
import { JobPortalService } from "./jobportalservice";
import { FormGroup, FormControl } from "@angular/forms";


@Component({
    selector:'search-desc',
    templateUrl:'app.searchbydescription.html'
})
export class SearchByDescription{
    searchD =new FormGroup({
        description : new FormControl(''),
    });   
    constructor(private service:JobPortalService){}
    job:Job[];
description:string;

    searchByDescription(){
        this.service.searchJobsByDescription(this.description).subscribe((data:any)=>this.job=data);
       }
}