import { Component } from "@angular/core";

import { JobPortalService } from "./jobportalservice";
import { FormGroup, FormControl } from "@angular/forms";


@Component({
    selector:'add-job',
    templateUrl:'app.job.html'
})
export class AddJob{

    jobbs=new FormGroup({
        description : new FormControl(''),
        vacancies : new FormControl(''),
        salary : new FormControl(''),
        city : new FormControl(''),
        provider : new FormControl(''),
    }); 
    constructor(private service:JobPortalService){}
    model:any={};

    addJob(job:any){
        console.log(this.model);
        this.service.addAllJob(this.model).
        subscribe((data:any)=>console.log(data));
        alert("Job Added Successfully!!");
    }
}