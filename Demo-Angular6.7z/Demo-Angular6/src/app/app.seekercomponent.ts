import { Component } from "@angular/core";

import { JobPortalService } from "./jobportalservice";
import { FormGroup, FormControl } from "@angular/forms";


@Component({
    selector:'add-seek',
    templateUrl:'app.jobseeker.html'
})
export class AddJobSeeker{
    seek=new FormGroup({
        name : new FormControl(''),
        email : new FormControl(''),
        contact : new FormControl(''),
        qualification : new FormControl(''),
        city : new FormControl(''),
    });   
    constructor(private service:JobPortalService){}
    model:any={};

    addJobSeeker(seeker:any){
        console.log(this.model);
        this.service.addAllJobSeeker(this.model).
        subscribe((data:any)=>console.log(data));
        alert("Seeker Added Successfully!!");
    }
}