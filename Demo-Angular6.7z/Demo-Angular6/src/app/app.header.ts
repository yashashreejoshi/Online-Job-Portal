import { Component } from "@angular/core";

@Component({
    selector:'header-job',
    templateUrl:'app.header.html'
})
export class JobHeader{

}