import { Injectable } from "@angular/core";
import { HttpClient, HttpParams} from "@angular/common/http";
import { throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';


@Injectable({
    providedIn:'root'
})
export class JobPortalService{

    constructor(private http:HttpClient){}
    
    addAllProvider(provider:any) {
        //return this.http.post("http://localhost:9098/product/addALL",prod);
        //console.log(prod);
        let input = new FormData();
        input.append("name",provider.name);
        input.append("email",provider.email);
        return this.http.post("http://localhost:9098/jobportal/addProvider",input).pipe(
            retry(1),
            catchError(this.handleError)
          );
    }

    addAllJob(job:any) {
        let input = new FormData();
      //  input.append("name",job.description);
        input.append("description",job.description);
        input.append("vacancies",job.vacancies);
        input.append("salary",job.salary);
        input.append("city",job.city);
        input.append("provider.id",job.providerid);
        return this.http.post("http://localhost:9098/jobportal/addJob",input).pipe(
            retry(1),
            catchError(this.handleError)
          );
    }

    addAllJobSeeker(seeker:any) {
        let input = new FormData();
        input.append("name",seeker.name);
        input.append("email",seeker.email);
        input.append("contact",seeker.contact);
        input.append("qualification",seeker.qualification);
        input.append("city",seeker.city);
        return this.http.post("http://localhost:9098/jobportal/addSeeker",input).pipe(
            retry(1),
            catchError(this.handleError)
          );
    }

    addAllApplication(application:any) {
        let input = new FormData();
        input.append("seeker.id",application.seekerid);
        input.append("job.id",application.jobid);
        return this.http.post("http://localhost:9098/jobportal/addApplication",input).pipe(
            retry(1),
            catchError(this.handleError)
          );;
    }

    searchJobsByDescription(description:string){
 let httpParams = new HttpParams().set("description",description);
 return this.http.get("http://localhost:9098/jobportal/searchDes",{params:httpParams}).pipe(
    retry(1),
    catchError(this.handleError)
  );;

} 

 searchJobsByCity(city:string){
    let httpParams = new HttpParams().set("city",city);
    return this.http.get("http://localhost:9098/jobportal/searchCity",{params:httpParams}).pipe(
        retry(1),
        catchError(this.handleError)
      );;
   } 
   
   handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // client-side error
      errorMessage = `Error: ${error.error}`;
    } else {
      // server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.error}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
  }
    
}