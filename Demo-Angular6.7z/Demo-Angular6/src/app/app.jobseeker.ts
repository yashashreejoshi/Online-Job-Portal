

export class JobSeeker {

    id:number;
    name:string;
    email:string;
    contact:number;
    qualification:string;
    city:string;
}