import { JobProvider } from "./app.jobprovider";


export class Job{
    id:number;
    description:string;
    vacancies:number;
    salary:number;
    city:string;
    provider:JobProvider

}