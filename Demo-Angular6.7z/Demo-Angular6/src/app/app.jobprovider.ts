

export class JobProvider {

    id:number;
    name:string;
    email:string;

    
}