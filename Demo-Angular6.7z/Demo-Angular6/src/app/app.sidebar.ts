import { Component } from "@angular/core";


@Component({
    selector:'side-job',
    templateUrl:'app.side.html'
})
export class JobSideBar{


}