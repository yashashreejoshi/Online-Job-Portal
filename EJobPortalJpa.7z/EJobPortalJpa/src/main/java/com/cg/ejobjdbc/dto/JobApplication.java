package com.cg.ejobjdbc.dto;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/*It is the POJO class for JobApplication including state and behaviour of Job Application.
 * Last Modified 06/05/2019  09.30 a.m.
 * Author: Yashashree Joshi
 */
@Entity
@Table(name="jobapplication")
public class JobApplication {

public JobApplication() {
		
	}
	
	public JobApplication(Date date, JobSeeker seeker, Job job) {
		super();
		this.date = date;
		this.seeker = seeker;
		this.job = job;
	}
	@Id
	@Column(name="application_id")
	private int id;							//attribute to store job application id
	private Date date;						//attribute to store job application date
	@ManyToOne(cascade =CascadeType.ALL)
	@JoinColumn(name="seeker_id")
	private JobSeeker seeker;				//attribute to store seeker details and refers to many to one relationship
	@OneToOne
	@JoinColumn(name="job_id")
	private Job job;						//attribute to store job details and refers to one to one relationship
	
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public JobSeeker getSeeker() {
		return seeker;
	}
	public void setSeeker(JobSeeker seeker) {
		this.seeker = seeker;
	}
	public Job getJob() {
		return job;
	}
	public void setJob(Job job) {
		this.job = job;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "JobApplication [id=" + id + ", date=" + date + ", seeker=" + seeker + ", job=" + job + "]";
	}
}
