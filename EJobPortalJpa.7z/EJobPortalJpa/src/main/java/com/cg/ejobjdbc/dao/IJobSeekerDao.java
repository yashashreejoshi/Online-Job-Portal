package com.cg.ejobjdbc.dao;

import com.cg.ejobjdbc.dto.JobSeeker;

public interface IJobSeekerDao {
	public JobSeeker save(JobSeeker seeker);
	public JobSeeker findById(int id);

}
