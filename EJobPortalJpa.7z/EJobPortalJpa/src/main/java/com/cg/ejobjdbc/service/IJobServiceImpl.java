package com.cg.ejobjdbc.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.ejobjdbc.dao.IJobDao;
import com.cg.ejobjdbc.dao.IJobDaoImpl;
import com.cg.ejobjdbc.dao.IJobSeekerDaoImpl;
import com.cg.ejobjdbc.dto.Job;
import com.cg.ejobjdbc.exception.JobIdNotFoundException;
import com.cg.ejobjdbc.exception.JobNotFoundException;

/*This class is a implementation of IJobService interface.
 * It includes saving of jobs, searching of jobs by job description and seaching of jobs by job city
 * also searching of jobs by job id.
 *
 * Last Modified 06/05/2019  09.30 a.m.
 * Author: Yashashree Joshi
 */
public class IJobServiceImpl implements IJobService {
	IJobDao jobDao;
	static int jobId=100;
	public IJobServiceImpl() {
		jobDao = new IJobDaoImpl();
		
	}
	public Job addJob(Job job) {
		job.setId(jobId);
		jobId++;
		return jobDao.save(job);
	}
	public List<Job> searchByJobDescription(String description) {
		List<Job> myList = jobDao.findByDescription(description);
		if(myList.isEmpty()) {
			throw new JobNotFoundException("Jobs u are searching are not available!!!");	
		}
		return myList;
	}
	public List<Job> searchByJobCity(String city) {
		List<Job> myList = jobDao.findByCity(city);
		if(myList.isEmpty()) {
			throw new JobNotFoundException("Jobs u are searching are not available!!!");
		}
		return  myList;
	}
	public Job searchByJobId(int id) {
		if(jobDao.findById(id)==null) {
			throw new JobIdNotFoundException("JOB ID NOT FOUND");
		}
		return jobDao.findById(id);
	}
	
}
