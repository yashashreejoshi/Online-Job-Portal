package com.cg.ejobjdbc.dao;

import java.sql.Connection;
import com.cg.ejobjdbc.util.DbUtil;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.ejobjdbc.dto.JobProvider;
import com.cg.ejobjdbc.dto.JobSeeker;
import com.cg.ejobjdbc.exception.EmployeeExe;

/*This class is implementation of IJobProviderRepository interface.
 * It includes saving of provider details, and searching of provider by id.
 * 
 * Last Modified 06/05/2019  09.30 a.m.
 * Author: Yashashree Joshi
 */
public class IJobProviderDaoImpl implements IJobProviderDao {
	EntityManager em;
	public IJobProviderDaoImpl() {
		em=DbUtil.em;
	}
	
	//adding provider
	public JobProvider save(JobProvider provider) {
		em.getTransaction().begin();
		em.persist(provider);
		em.getTransaction().commit();
		
		
		return null;
	}

	//finding provider
	public JobProvider findById(int id) {
	JobProvider provider = new JobProvider();
	provider=em.find(JobProvider.class,id);
	return provider;
		
		
}}
