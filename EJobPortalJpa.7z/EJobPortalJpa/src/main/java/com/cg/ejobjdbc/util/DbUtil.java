package com.cg.ejobjdbc.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.ejobjdbc.exception.EmployeeExe;



public class DbUtil {

public	static  EntityManager em=Persistence.createEntityManagerFactory("ejobportal").createEntityManager();  

}
