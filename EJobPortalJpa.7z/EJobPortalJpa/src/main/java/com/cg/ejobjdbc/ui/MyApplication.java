package com.cg.ejobjdbc.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Date;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.ejobjdbc.dto.Job;
import com.cg.ejobjdbc.dto.JobApplication;
import com.cg.ejobjdbc.dto.JobProvider;
import com.cg.ejobjdbc.dto.JobSeeker;
import com.cg.ejobjdbc.exception.EmployeeExe;
import com.cg.ejobjdbc.exception.JobAppliedNotFoundException;
import com.cg.ejobjdbc.exception.JobIdNotFoundException;
import com.cg.ejobjdbc.exception.JobNotFoundException;
import com.cg.ejobjdbc.exception.SeekerNotFoundException;
import com.cg.ejobjdbc.service.IJobApplicationService;
import com.cg.ejobjdbc.service.IJobApplicationServiceImpl;
import com.cg.ejobjdbc.service.IJobProviderService;
import com.cg.ejobjdbc.service.IJobProviderServiceImpl;
import com.cg.ejobjdbc.service.IJobSeekerService;
import com.cg.ejobjdbc.service.IJobSeekerServiceImpl;
import com.cg.ejobjdbc.service.IJobService;
import com.cg.ejobjdbc.service.IJobServiceImpl;



public class MyApplication {
	static IJobService jobService;
	static IJobSeekerService seekerService;
	static IJobProviderService providerService;
	static IJobApplicationService applicationService;

	
	public static void main(String[] args) throws IOException{
		jobService = new IJobServiceImpl();
		providerService = new IJobProviderServiceImpl();
		seekerService = new IJobSeekerServiceImpl();
		applicationService = new IJobApplicationServiceImpl(); 
		JobProvider provider=null;
		JobSeeker seeker=null;
		Job job = null;
		JobApplication application = null;
		Date date;
		Scanner scr = new Scanner(System.in);
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	
		int ch;
		do {
			print();
		ch=scr.nextInt();
		switch(ch) {
		case 1: 
			//adding provider
			
			System.out.println("enter provider name");
			String name= br.readLine();
			System.out.println("enter provider email");
			String email= br.readLine();
			provider = new JobProvider(name,email);
			providerService.addProvider(provider);
		
			break;
			
		case 2:
			//adding job
			
			System.out.println("enter job description");
			String description= br.readLine();
			System.out.println("enter job vacancies");
			int vacancies= scr.nextInt();
			System.out.println("enter job salary");
			BigDecimal salary = scr.nextBigDecimal();
			System.out.println("Enter job city");
			String city = scr.next();
			System.out.println("Enter provider id");
			int providerId= scr.nextInt();
			provider=providerService.searchByProviderId(providerId);
			System.out.println(provider);
			job = new Job(description,vacancies,salary,city,provider);
			jobService.addJob(job);
			break;
		case 3:
			//adding seeker
			
			System.out.println("enter seeker name");
			String seekerName= scr.next();
			System.out.println("enter seeker email");
			String seekerEmail= scr.next();
			System.out.println("enter seeker contact");
			BigInteger mobile = scr.nextBigInteger();
			System.out.println("Enter seeker qualification");
			String qualification = scr.next();
			System.out.println("Enter seeker city");
			String seekerCity = scr.next();
			seeker = new JobSeeker(seekerName, seekerEmail, mobile, qualification, seekerCity);
			try {
			seekerService.addSeeker(seeker);
			}catch(EmployeeExe e) {
				System.out.println(e.getMessage());
			}
			break;
			
		case 4:
			//searching jobs by job_description
			System.out.println("Enter job description to search");
			String describe= br.readLine();
			try {
			List<Job> jobSearch = jobService.searchByJobDescription(describe);
			System.out.println(jobSearch);
			for(Job allJob: jobSearch) {
				System.out.println(describe+"jobs :");
			System.out.println("Job Id "+allJob.getId());
			System.out.println("Job Description "+ allJob.getDescription());
			System.out.println("Job Vacancies " +allJob.getVacancies());
			System.out.println("Job City "+allJob.getCity());
			System.out.println("Provided By "+allJob.getProvider());
			}
			}catch(JobNotFoundException e) {
				System.out.println(e.getMessage());
			}
			break; 
		case 5:
			//searching job by city
			System.out.println("Enter job city to search");
			String location =br.readLine();
			try {
			List<Job> searchJob = jobService.searchByJobCity(location);
			for(Job allJob: searchJob) {
				System.out.println(location+"jobs :");
				System.out.println("Job Id "+allJob.getId());
				System.out.println("Job Description "+ allJob.getDescription());
				System.out.println("Job Vacancies " +allJob.getVacancies());
				System.out.println("Job City "+allJob.getCity());
				System.out.println("Provided By "+allJob.getProvider());
				}
			}catch(JobNotFoundException e) {
				System.out.println(e.getMessage());
			}
			break;
		case 6:
			//applying to job 
		
			System.out.println("Enter seeker id");
			int seekId = scr.nextInt();
			try {
				seeker = seekerService.searchBySeekerId(seekId);
				}catch(SeekerNotFoundException e) { System.out.println(e.getMessage()); break; } 
			System.out.println("Enter job id");
			int applyId = scr.nextInt();
			try {
				job = jobService.searchByJobId(applyId);
				}catch(JobIdNotFoundException e) { System.out.println(e.getMessage()); break; }
			catch(EmployeeExe e) { System.out.println(e.getMessage()); break; }
			System.out.println("Enter date in YY//MM/dd");
			long millis=System.currentTimeMillis();
			Date dateTwo = new Date(millis);
			System.out.println(dateTwo);
			application = new JobApplication(dateTwo,seeker,job);
			try {
			applicationService.applyJob(application);
			System.out.println("Applied Successfully to Job_id " + applyId);
			}catch(JobAppliedNotFoundException e) { 
				System.out.println(e.getMessage()); break;}
				break;
				
		case 7:
			System.out.println("EXITTED");
			System.exit(1);
			break;
		
		}
	}while(ch!=0);
		}
	static void print() {
		System.out.println("1. Add Provider");	
		System.out.println("2. Add Job");
		System.out.println("3. Add Seeker");
		System.out.println("4. Search By Job Description");
		System.out.println("5. Search by Job City");
		System.out.println("6. Apply for Job");
		System.out.println("7. Exit");
		System.out.println("Enter your choice");
	}
}
