package com.cg.ejobjdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.ejobjdbc.dto.JobApplication;
import com.cg.ejobjdbc.exception.EmployeeExe;
import com.cg.ejobjdbc.exception.JobAppliedNotFoundException;
import com.cg.ejobjdbc.util.DbUtil;

/*This class is a implementation of IJobApplication repository interface.
 * It includes saving of job application.
 *
 * Last Modified 06/05/2019  09.30 a.m.
 * Author: Yashashree Joshi
 */

public class IJobApplicationDaoImpl implements IJobApplicationDao {
	EntityManager em;
	public IJobApplicationDaoImpl() {
		em=DbUtil.em;
	}
	
	//inserting job application
	public JobApplication save(JobApplication application) {
		em.getTransaction().begin();
		em.persist(application);
		em.getTransaction().commit();
		
		return null;
	}

	
}
