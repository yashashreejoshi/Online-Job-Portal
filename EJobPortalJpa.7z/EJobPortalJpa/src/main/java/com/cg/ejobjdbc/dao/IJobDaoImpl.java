package com.cg.ejobjdbc.dao;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.math.BigInteger;
import java.security.Provider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.cg.ejobjdbc.dto.Job;
import com.cg.ejobjdbc.dto.JobProvider;
import com.cg.ejobjdbc.dto.JobSeeker;
import com.cg.ejobjdbc.exception.EmployeeExe;
import com.cg.ejobjdbc.exception.JobIdNotFoundException;
import com.cg.ejobjdbc.util.DbUtil;
import com.cg.ejobjdbc.exception.JobNotFoundException;

/*This class is implementation of IJobRepository implementation.
 * It includes saving of jobs, searching of jobs by job description and seaching of jobs by job city
 * also searching of jobs by job id.
 * 
 * Last Modified 06/05/2019  09.30 a.m.
 * Author: Yashashree Joshi
 */
public class IJobDaoImpl implements IJobDao {
	EntityManager em;
	public IJobDaoImpl() {
		em=DbUtil.em;
	}
	
	//inserting job
	public Job save(Job job) {
			em.getTransaction().begin();
			em.persist(job);
			em.getTransaction().commit();
	
			return null;
	}

	//finding job by job description
	public List<Job> findByDescription(String description) {
		Query query=em.createQuery("FROM Job j WHERE j.description = :description");
		query.setParameter("description", description);
		List<Job> jobList=query.getResultList();
		return jobList;
	}
	
	//finding job by city name
	public List<Job> findByCity(String city) {
		Query query=em.createQuery("FROM Job j WHERE j.city = :city");
		query.setParameter("city", city);
		List<Job> jobList=query.getResultList();
		return jobList;
	}

	//finding jobs by job id
	public Job findById(int id) {
		//em= DbUtil.em;
		Job job = new Job();
		job=em.find(Job.class,id);
		return job;
		
	}
}
