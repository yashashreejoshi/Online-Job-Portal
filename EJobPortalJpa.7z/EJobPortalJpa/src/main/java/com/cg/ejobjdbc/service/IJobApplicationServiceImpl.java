package com.cg.ejobjdbc.service;

import java.util.List;

import com.cg.ejobjdbc.dao.IJobApplicationDao;
import com.cg.ejobjdbc.dao.IJobApplicationDaoImpl;
import com.cg.ejobjdbc.dto.JobApplication;

/*This class is a implementation of IJobApplication service interface.
 * It includes saving of job application.
 *
 * Last Modified 06/05/2019  09.30 a.m.
 * Author: Yashashree Joshi
 */
public class IJobApplicationServiceImpl implements IJobApplicationService {
IJobApplicationDao applicationDao;
static int applicationId=10;
	public IJobApplicationServiceImpl() {
		applicationDao = new IJobApplicationDaoImpl();
	}
	public JobApplication applyJob(JobApplication application) {
		application.setId(applicationId);
		applicationId++;
		return applicationDao.save(application);
	}

}
