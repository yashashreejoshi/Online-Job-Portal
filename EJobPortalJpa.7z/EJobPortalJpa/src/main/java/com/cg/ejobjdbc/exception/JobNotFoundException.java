package com.cg.ejobjdbc.exception;

public class JobNotFoundException extends RuntimeException {
	public JobNotFoundException() { }
	public JobNotFoundException(String msg) {
		super(msg);
	}
}
