package com.cg.ejobjdbc.dto;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/*It is the POJO class for JobProvider including state and behaviour of provider.
 * Last Modified 06/05/2019  09.30 a.m.
 * Author: Yashashree Joshi
 */
@Entity @Table(name="jobprovider")
public class JobProvider {

	public JobProvider() {
		super();
	}
	public JobProvider(String name, String email) {
		super();
		this.name = name;
		this.email = email;
	}
	@Id 
	
	@Column(name="provider_id")
	private int id;				//attribute to store provider id
	private String name;		//attribute to store provider name
	private String email;		//attribute to store provider email
	//private Job job;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "JobProvider [id=" + id + ", name=" + name + ", email=" + email + "]";
	}
}
