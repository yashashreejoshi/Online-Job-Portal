package com.cg.ejobjdbc.service;

import com.cg.ejobjdbc.dao.IJobProviderDao;
import com.cg.ejobjdbc.dao.IJobProviderDaoImpl;
import com.cg.ejobjdbc.dto.JobProvider;

/*This class is a implementation of IJobProvider service interface.
 * It includes saving of provider details and searching provider by id.
 *
 * Last Modified 06/05/2019  09.30 a.m.
 * Author: Yashashree Joshi
 */
public class IJobProviderServiceImpl implements IJobProviderService {

IJobProviderDao providerDao;
static int providerId=200;
	
	public IJobProviderServiceImpl() {
		providerDao = new IJobProviderDaoImpl();
	}

	public JobProvider addProvider(JobProvider provider) {
		provider.setId(providerId);
		providerId++;
		return providerDao.save(provider);
	}

	public JobProvider searchByProviderId(int id) {
		return providerDao.findById(id);
		
	}

}
