package com.cg.ejobjdbc.util;

import java.util.ArrayList;
import java.util.List;

import com.cg.ejobjdbc.dto.JobProvider;


public class DBUtilJobProvider {
	public static List<JobProvider> providers = new ArrayList<JobProvider>();

}
