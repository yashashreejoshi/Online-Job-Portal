package com.cg.ejobjdbc.service;

import com.cg.ejobjdbc.dao.IJobSeekerDao;
import com.cg.ejobjdbc.dao.IJobSeekerDaoImpl;
import com.cg.ejobjdbc.dto.JobSeeker;

/*This class is implementation of IJobSeekerService interface.
 * It includes saving seeker details and searching of seeker by id.
 * 
 * Last Modified 06/05/2019  09.30 a.m.
 * Author: Yashashree Joshi
 */
public class IJobSeekerServiceImpl implements IJobSeekerService {
	IJobSeekerDao seekerDao;
	static int seekerId=500;
	public IJobSeekerServiceImpl() {
		seekerDao = new IJobSeekerDaoImpl();
	}

	
	public JobSeeker addSeeker(JobSeeker seeker) {
		seeker.setId(seekerId);
		seekerId++;
		return seekerDao.save(seeker);
	}

	public JobSeeker searchBySeekerId(int id) {
		return seekerDao.findById(id);
	}

}
