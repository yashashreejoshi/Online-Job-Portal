package com.cg.ejobjdbc.dto;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/*It is the POJO class for JobSeeker including state and behaviour of seeker.
 * Last Modified 06/05/2019  09.30 a.m.
 * Author: Yashashree Joshi
 */
@Entity @Table(name="jobseeker")
public class JobSeeker {

	public JobSeeker() {
		super();
	}
	public JobSeeker(String name, String email, BigInteger contact, String qualification, String city) {
		super();
		this.name = name;
		this.email = email;
		this.contact = contact;
		this.qualification = qualification;
		this.city = city;
	}
	@Id 
	
	@Column(name="seeker_id")
	private int id;							//attribute to store seeker id
	private String name;					//attribute to store seeker name
	private String email;					//attribute to store seeker email
	private BigInteger contact;				//attribute to store seeker conatct
	private String qualification;			//attribute to store seeker qualification
	private String city;					//attribute to store seeker city
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public BigInteger getContact() {
		return contact;
	}
	public void setContact(BigInteger contact) {
		this.contact = contact;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "JobSeeker [id=" + id + ", name=" + name + ", email=" + email + ", contact=" + contact
				+ ", qualification=" + qualification + ", city=" + city + "]";
	}
}
