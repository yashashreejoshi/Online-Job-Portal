package com.cg.ejobjdbc.dao;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.EntityManager;

import com.cg.ejobjdbc.dto.JobProvider;
import com.cg.ejobjdbc.dto.JobSeeker;
import com.cg.ejobjdbc.exception.EmployeeExe;
import com.cg.ejobjdbc.util.DbUtil;

/*This class is implementation of IJobSeekerRepository interface.
 * It includes saving seeker details and searching of seeker by id.
 * 
 * Last Modified 06/05/2019  09.30 a.m.
 * Author: Yashashree Joshi
 */
public class IJobSeekerDaoImpl implements IJobSeekerDao {
 EntityManager em;
 public IJobSeekerDaoImpl() {
	em=DbUtil.em;
	}
		//inserting seeker
	public JobSeeker save(JobSeeker seeker) {
		em.getTransaction().begin();
		em.persist(seeker);
		em.getTransaction().commit();
		
		return null;
	}

	//finding seeker
	public JobSeeker findById(int id) {
		JobSeeker seeker = new JobSeeker();
		seeker=em.find(JobSeeker.class,id);
		return seeker;
}
}
