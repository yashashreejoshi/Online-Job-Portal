package com.cg.ejobjdbc.dto;

import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/*It is the POJO class for Job including state and behaviour of job.
 * Last Modified 06/05/2019  09.30 a.m.
 * Author: Yashashree Joshi
 */
@Entity
@Table(name="job")
public class Job {

	public Job() {
		super();
	}
	public Job(String description, int vacancies, BigDecimal salary, String city, JobProvider provider) {
		super();
		this.description = description;
		this.vacancies = vacancies;
		this.salary = salary;
		this.city = city;
		this.provider = provider;
	}
	@Id

	@Column(name="job_id")
	private int id;						//attribute to store job id and primary key in database
	private String description;			//attribute to store job description
	private int vacancies;				//attribute to store job vacancies
	private BigDecimal salary;			//attribute to store job salary
	private String city;				//attribute to store job city
	@ManyToOne(targetEntity=JobProvider.class)
	@JoinColumn(name="provider_id")
	private JobProvider provider;		//attribute to store provider object and also refers to many to one relationship
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getVacancies() {
		return vacancies;
	}
	public void setVacancies(int vacancies) {
		this.vacancies = vacancies;
	}
	public BigDecimal getSalary() {
		return salary;
	}
	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public JobProvider getProvider() {
		return provider;
	}
	public void setProvider(JobProvider provider) {
		this.provider = provider;
	}
	@Override
	public String toString() {
		return "Job [id=" + id + ", description=" + description + ", vacancies=" + vacancies + ", salary=" + salary
				+ ", city=" + city + ", provider=" + provider + "]";
	}
	
}
