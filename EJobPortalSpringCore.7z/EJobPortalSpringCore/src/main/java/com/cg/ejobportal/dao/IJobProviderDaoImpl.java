package com.cg.ejobportal.dao;

import java.nio.file.ProviderNotFoundException;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.ejobportal.dto.JobProvider;
import com.cg.ejobportal.util.DBUtilProvider;

/*This class is a implementation of IJobProvider repository interface.
*
*
* @Last Modified 14/05/2019  07.30 p.m.
* @Author: Yashashree Joshi
*/
@Repository("providerDao")
public class IJobProviderDaoImpl implements IJobProviderDao {
	
	static final Logger logger = Logger.getLogger(IJobProviderDaoImpl.class);
	/*This method is a implementation of IJobProvider repository interface method.
	 * It includes saving of job provider.
	 * 
	 * @param args JobProvider provider
	 * @return JobProvider
	 * 
	 * @Last Modified 14/05/2019  07.30 p.m.
	 * @Author: Yashashree Joshi
	 */
	public JobProvider save(JobProvider provider) {
		BasicConfigurator.configure();
		DBUtilProvider.providers.add(provider);
		logger.info("adding the PROVIDER");
		return provider;
	}

	/*This method is a implementation of IJobProvider repository interface method.
 	 * It includes searching of job provider by id.
 	 * 
 	 * @param args int id. 
 	 * @return JobProvider.
 	 * 
 	 * @Last Modified 14/05/2019  07.30 p.m.
 	 * @Author: Yashashree Joshi
 	 */
	public JobProvider findById(int id) {
		for(JobProvider provide: DBUtilProvider.providers) {
			if(provide.getId()==id) {
				return provide;	
			}
			else {
				throw new ProviderNotFoundException("Id not found");
			}
		}
	return null;
	}
	

}
