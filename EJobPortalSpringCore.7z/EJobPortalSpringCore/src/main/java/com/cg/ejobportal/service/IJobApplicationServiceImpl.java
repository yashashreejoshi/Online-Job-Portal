package com.cg.ejobportal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ejobportal.dao.IJobApplicationDao;
import com.cg.ejobportal.dao.IJobApplicationDaoImpl;
import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobApplication;
import com.cg.ejobportal.dto.JobSeeker;
/*This class is a implementation of IJobApplication service interface.
 * It includes saving of job application.
 *
 *
 * Last Modified 06/05/2019  07.30 a.m.
 * Author: Yashashree Joshi
 */
@Service("applicationService")
public class IJobApplicationServiceImpl implements IJobApplicationService {
	@Autowired
	IJobApplicationDao applicationDao;
	
	/*This method is used to save jobApplication.
	 *
	 * @param args JobApplication application. 
	 * @return List<JobApplication>.
	 * 
	 * Last Modified 14/05/2019  07.30 p.m.
	 * Author: Yashashree Joshi
	 */
	public List<JobApplication> applyJob(JobApplication application) {
		return applicationDao.save(application);
	}

}
