package com.cg.ejobportal.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ejobportal.dao.IJobDao;
import com.cg.ejobportal.dao.IJobDaoImpl;
import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.exception.JobIdNotFoundException;
import com.cg.ejobportal.exception.JobNotFoundException;

/*This class is a implementation of IJobService interface.
*
* Last Modified 14/05/2019  07.30 p.m.
* Author: Yashashree Joshi
*/
@Service("jobService")
public class IJobServiceImpl implements IJobService{
	@Autowired
	IJobDao jobDao;
	
	/*This method is a implementation of IJobService interface method.
	 * It includes saving of jobs.
	 * 
	 * @param args Job job. 
	 * @return Job.
	 * 
	 * Last Modified 14/05/2019  07.30 p.m.
	 * Author: Yashashree Joshi
	 */
	public Job addJob(Job job) {
		return jobDao.save(job);
	}
	

	/*This method is a implementation of IJobService interface method.
	 * It includes searching of jobs by description.
	 * 
	 * @param args String description. 
	 * @return List<Job>.
	 * 
	 * Last Modified 14/05/2019  07.30 p.m.
	 * Author: Yashashree Joshi
	 */
	public List<Job> searchByJobDescription(String description) {
		List<Job> storeJobs = jobDao.findByDescription(description);
		if(storeJobs.isEmpty())
			throw new JobNotFoundException("Jobs you are searching are not available");
		return jobDao.findByDescription(description);
		
	}
	
	/*This method is a implementation of IJobService interface method.
	 * It includes searching of jobs by city.
	 * 
	 * @param args String city. 
	 * @return List<Job>.
	 * 
	 * Last Modified 14/05/2019  07.30 p.m.
	 * Author: Yashashree Joshi
	 */
	public List<Job> searchByJobCity(String city) {
		List<Job> storeJobs = jobDao.findByCity(city);
		if(storeJobs.isEmpty())
			throw new JobNotFoundException("Jobs you are searching are not available");
		return jobDao.findByCity(city);
	}
	
	/*This method is a implementation of IJobService interface method.
	 * It includes searching of jobs by id.
	 * 
	 * @param args int id. 
	 * @return Job.
	 * 
	 * Last Modified 14/05/2019  07.30 p.m.
	 * Author: Yashashree Joshi
	 */

	public Job searchByJobId(int id) {
		Job job=jobDao.findById(id);
		if(job==null)
			throw new JobIdNotFoundException("job id not found");
		return job;
	}
}
