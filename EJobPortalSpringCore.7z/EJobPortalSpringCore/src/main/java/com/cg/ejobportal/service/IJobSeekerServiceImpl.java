package com.cg.ejobportal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ejobportal.dao.IJobSeekerDao;
import com.cg.ejobportal.dao.IJobSeekerDaoImpl;
import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobSeeker;
import com.cg.ejobportal.exception.JobIdNotFoundException;
import com.cg.ejobportal.exception.SeekerNotFoundException;

/*This class is a implementation of IJobSeeker service interface.
*
*
* Last Modified 14/05/2019  07.30 p.m.
* Author: Yashashree Joshi
*/
@Service("seekerService")    //this will create service bean
public class IJobSeekerServiceImpl implements IJobSeekerService{
	@Autowired				
	IJobSeekerDao seekerDao;
	

	/*This method is a implementation of IJobSeeker service interface method.
	 * It includes saving of job seeker.
	 * 
	 * @param args JobSeeker seeker. 
	 * @return JobSeeker.
	 * 
	 * Last Modified 14/05/2019  07.30 p.m.
	 * Author: Yashashree Joshi
	 */
	public JobSeeker addSeeker(JobSeeker seeker) {
		// TODO Auto-generated method stub
		return seekerDao.save(seeker);
	}


	/*This method is a implementation of IJobSeeker Service interface method.
	 * It includes searching of jobs by id.
	 * 
	 * @param args int id. 
	 * @return Job.
	 * 
	 * Last Modified 14/05/2019  07.30 p.m.
	 * Author: Yashashree Joshi
	 */
	public JobSeeker searchBySeekerId(int id) {
		// TODO Auto-generated method stub
		JobSeeker seeker=seekerDao.findById(id);
		if(seeker==null)
			throw new SeekerNotFoundException("seeker not found");
		return seeker;
	
	}

}
