package com.cg.ejobportal.service;

import com.cg.ejobportal.dto.JobSeeker;

public interface IJobSeekerService {
	public JobSeeker addSeeker(JobSeeker seeker);
	public JobSeeker searchBySeekerId(int id);

}
