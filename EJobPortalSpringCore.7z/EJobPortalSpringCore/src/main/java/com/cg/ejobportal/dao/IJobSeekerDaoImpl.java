package com.cg.ejobportal.dao;

import java.nio.file.ProviderNotFoundException;

import org.springframework.stereotype.Repository;

import com.cg.ejobportal.dto.JobProvider;
import com.cg.ejobportal.dto.JobSeeker;
import com.cg.ejobportal.exception.SeekerNotFoundException;
import com.cg.ejobportal.util.DBUtilProvider;
import com.cg.ejobportal.util.DBUtilSeeker;

/*This class is a implementation of IJobSeeker repository interface.
*
*
* Last Modified 14/05/2019  07.30 p.m.
* Author: Yashashree Joshi
*/
@Repository("seekerDao")  //this annotation will create the repository bean
public class IJobSeekerDaoImpl implements IJobSeekerDao{
	
	/*This method is a implementation of IJobSeeker service interface method.
	 * It includes saving of job seeker.
	 * 
	 * @param args JobSeeker seeker. 
	 * @return JobSeeker.
	 * 
	 * Last Modified 14/05/2019  07.30 p.m.
	 * Author: Yashashree Joshi
	 */
	public JobSeeker save(JobSeeker seeker) {
		// TODO Auto-generated method stub
		DBUtilSeeker.seekers.add(seeker);
		return seeker;
	}

	/*This method is a implementation of IJobSeeker Service interface method.
	 * It includes searching of jobs by id.
	 * 
	 * @param args int id. 
	 * @return Job.
	 * 
	 * Last Modified 14/05/2019  07.30 p.m.
	 * Author: Yashashree Joshi
	 */
	public JobSeeker findById(int id) {
		for(JobSeeker seek: DBUtilSeeker.seekers) {
			if(seek.getId()==id) {
				return seek;	
			}
		
		}
	return null;
	}

}
