package com.cg.ejobportal.dao;

import com.cg.ejobportal.dto.JobSeeker;

public interface IJobSeekerDao {
	public JobSeeker save(JobSeeker seeker);
	public JobSeeker findById(int id);

}
