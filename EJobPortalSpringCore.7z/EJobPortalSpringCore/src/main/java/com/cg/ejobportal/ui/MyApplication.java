package com.cg.ejobportal.ui;

import java.math.BigDecimal;
	import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
	import java.util.Scanner;


import javax.annotation.PostConstruct;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.ejobportal.config.JavaConfiguration;
import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobApplication;
import com.cg.ejobportal.dto.JobProvider;
	import com.cg.ejobportal.dto.JobSeeker;
import com.cg.ejobportal.exception.JobAppliedNotFoundException;
import com.cg.ejobportal.exception.JobIdNotFoundException;
import com.cg.ejobportal.exception.JobNotFoundException;
import com.cg.ejobportal.exception.SeekerNotFoundException;
import com.cg.ejobportal.service.IJobApplicationService;
	import com.cg.ejobportal.service.IJobApplicationServiceImpl;
	import com.cg.ejobportal.service.IJobProviderService;
	import com.cg.ejobportal.service.IJobProviderServiceImpl;
	import com.cg.ejobportal.service.IJobSeekerService;
	import com.cg.ejobportal.service.IJobSeekerServiceImpl;
	import com.cg.ejobportal.service.IJobService;
	import com.cg.ejobportal.service.IJobServiceImpl;
import com.cg.ejobportal.util.DBUtilJob;

import java.math.BigInteger;
import java.util.List;
import java.util.Scanner;

import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobProvider;
import com.cg.ejobportal.dto.JobSeeker;
import com.cg.ejobportal.service.IJobApplicationService;
import com.cg.ejobportal.service.IJobApplicationServiceImpl;
import com.cg.ejobportal.service.IJobProviderService;
import com.cg.ejobportal.service.IJobProviderServiceImpl;
import com.cg.ejobportal.service.IJobSeekerService;
import com.cg.ejobportal.service.IJobSeekerServiceImpl;
import com.cg.ejobportal.service.IJobService;
import com.cg.ejobportal.service.IJobServiceImpl;

/** 
 * This is the main class bean which makes use of all the functionalities in the project. 
 * @param args Unused. 
 * @return Nothing. 
 * 
 *  Last Modified 14/05/2019  07.30 p.m.
 *  @Author: Yashashree Joshi
 */ 
@Component
public class MyApplication {
	

	static IJobService jobService;
	static IJobSeekerService seekerService;
	static IJobProviderService providerService;
	static IJobApplicationService applicationService;


	@Autowired
	 IJobService jobServices;
	@Autowired
	 IJobSeekerService seekerServices;
	@Autowired
	 IJobProviderService providerServices;
	@Autowired
	 IJobApplicationService applicationServices;
	
	@PostConstruct
	public void init() {
		jobService=this.jobServices;
		seekerService=this.seekerServices;
		providerService=this.providerServices;
		applicationService=this.applicationServices;
	}
	
	public static void main(String[] args){
	
		AnnotationConfigApplicationContext app = new AnnotationConfigApplicationContext(JavaConfiguration.class);
	
		JobProvider provider=null;
		JobSeeker seeker=null;
		Job job = null;
		JobApplication application = null;
		Date date;
		Scanner scr = new Scanner(System.in);
		int ch;
		do {
			print();
		ch=scr.nextInt();
		switch(ch) {
		case 1: 
			/*
			 * 
			 * @Last Modified on 14-05-2019 07.30 p.m.
			 * The Following case is for Adding provider into collection
			 *@return the provider
			 */  
			System.out.println("enter provider id");
			int id= scr.nextInt();
			System.out.println("enter provider name");
			String name= scr.next();
			System.out.println("enter provider email");
			String email= scr.next();
			provider=(JobProvider) app.getBean("jobprovider");
			provider.setId(id);
			provider.setName(name);
			provider.setEmail(email);
			providerService.addProvider(provider);
			break;
			
		case 2:
			/*
			 * 
			 * @Last Modified on 14-05-2019 07.30 p.m.
			 * The Following case is for Adding job into collection
			 *@return the job
			 */ 
			System.out.println("enter job id");
			int jobId= scr.nextInt();
			System.out.println("enter job description");
			String description= scr.next();
			System.out.println("enter job vacancies");
			int vacancies= scr.nextInt();
			System.out.println("enter job salary");
			BigDecimal salary = scr.nextBigDecimal();
			System.out.println("Enter job city");
			String city = scr.next();
			System.out.println("Enter provider name");
			String providerName= scr.next();
			if(providerName.equals(provider.getName()))
				provider.setName(providerName);
			job=(Job) app.getBean("job");
			job.setId(jobId);
			job.setDescription(description);
			job.setVacancies(vacancies);
			job.setSalary(salary);
			job.setCity(city);
			job.setProvider(provider);
			jobService.addJob(job);
			break;
		case 3:
			/*
			 * 
			 * @Last Modified on 14-05-2019 07.30 p.m.
			 * The Following case is for Adding seeker.
			 *@return the seeker
			 */ 
			System.out.println("enter seeker id");
			int seekerId= scr.nextInt();
			System.out.println("enter seeker name");
			String seekerName= scr.next();
			System.out.println("enter seeker email");
			String seekerEmail= scr.next();
			System.out.println("enter seeker contact");
			BigInteger mobile = scr.nextBigInteger();
			System.out.println("Enter seeker qualification");
			String qualification = scr.next();
			System.out.println("Enter seeker city");
			String seekerCity = scr.next();
			
			seeker=(JobSeeker) app.getBean("jobseeker");
			seeker.setId(seekerId);
			seeker.setName(seekerName);
			seeker.setEmail(seekerEmail);
		    seeker.setContact(mobile);
		    seeker.setQualification(qualification);
		    seeker.setCity(seekerCity);
			seekerService.addSeeker(seeker);
			break;
			
		case 4:
			/*
			 * 
			 * @Last Modified on 14-05-2019 07.30 p.m.
			 * The Following case is for searching jobs by description
			 *@return the List<Job>
			 */ 
			System.out.println("Enter job description to search");
			String describe= scr.next();
			try {
			List<Job> jobSearch = jobService.searchByJobDescription(describe);
			for(Job allJob: jobSearch) {
				System.out.println(describe+"jobs :");
			System.out.println("Job Id "+allJob.getId());
			System.out.println("Job Description "+ allJob.getDescription());
			System.out.println("Job Vacancies " +allJob.getVacancies());
			System.out.println("Job City "+allJob.getCity());
			System.out.println("Provided By "+allJob.getProvider());
			}
			}catch(JobNotFoundException e) {
				System.out.println(e.getMessage());
			}
			break; 
		case 5:
			/*
			 * 
			 * @Last Modified on 14-05-2019 07.30 p.m.
			 * The Following case is for searching jobs by city
			 *@return the List<Job>
			 */ 
			System.out.println("Enter job city to search");
			String location = scr.next();
			try {
			List<Job> searchJob = jobService.searchByJobCity(location);
			for(Job allJob: searchJob) {
				System.out.println(location+"jobs :");
				System.out.println("Job Id "+allJob.getId());
				System.out.println("Job Description "+ allJob.getDescription());
				System.out.println("Job Vacancies " +allJob.getVacancies());
				System.out.println("Job City "+allJob.getCity());
				System.out.println("Provided By "+allJob.getProvider());
				}
			}catch(JobNotFoundException e) {
				System.out.println(e.getMessage());
			}
			break;
		case 6:
			/*
			 * 
			 * @Last Modified on 14-05-2019 07.30 p.m.
			 * The Following case is for applying to job
			 *@return the application
			 */ 
			System.out.println("Enter you apply id");
			int apply=scr.nextInt();
			System.out.println("Enter seeker id");
			int seekId = scr.nextInt();
			try {
				seeker = seekerService.searchBySeekerId(seekId);
				}catch(SeekerNotFoundException e) { System.out.println(e.getMessage()); break; } 
			System.out.println("Enter job id");
			int applyId = scr.nextInt();
			try {
				job = jobService.searchByJobId(applyId);
					}catch(JobIdNotFoundException e) { System.out.println(e.getMessage()); break; }
			System.out.println("Enter date in dd/MM/YY");
			
			Date dateTwo = new Date();
			
			application = (JobApplication) app.getBean("jobapplication");
			application.setId(apply);
			application.setSeeker(seeker);
			application.setJob(job);
			application.setDate(dateTwo);
			List<JobApplication> appliedJobs = applicationService.applyJob(application);
				for(JobApplication j : appliedJobs)
					System.out.println(j);
				break;
		case 7:
			System.exit(1);
		
		}
	}while(ch!=0);
		}
	static void print() {
		System.out.println("1. Add Provider");	
		System.out.println("2. Add Job");
		System.out.println("3. Add Seeker");
		System.out.println("4. Search By Job Description");
		System.out.println("5. Search by Job City");
		System.out.println("6. Apply for Job");
		System.out.println("7. Exit");
		System.out.println("Enter your choice");
	}
}
