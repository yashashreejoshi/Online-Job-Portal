package com.cg.ejobportal.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/*
 * This class is responsible for creating beans of all the classes under given package.
 * 
 *  Last Modified 14/05/2019  07.30 p.m.
 * @Author: Yashashree Joshi.
 * 
 * */
@Configuration
@ComponentScan("com.cg.ejobportal")
public class JavaConfiguration {

	
}
