package com.cg.ejobjdbc.exception;

public class SeekerNotFoundException extends RuntimeException {
	public SeekerNotFoundException() { }
	public SeekerNotFoundException(String msg) {
		super(msg);
	}
}
