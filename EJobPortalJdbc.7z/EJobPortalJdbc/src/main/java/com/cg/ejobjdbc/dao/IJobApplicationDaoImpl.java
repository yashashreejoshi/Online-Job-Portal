package com.cg.ejobjdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.cg.ejobjdbc.dto.JobApplication;
import com.cg.ejobjdbc.exception.EmployeeExe;
import com.cg.ejobjdbc.util.DbUtil;

public class IJobApplicationDaoImpl implements IJobApplicationDao {

	public JobApplication save(JobApplication application) {
		Connection con = DbUtil.getConnection();
		String query_insert="INSERT INTO jobapplication VALUES(?,?,?,?)";
		PreparedStatement pstmt=null;
		try {
			pstmt = con.prepareStatement(query_insert);
			pstmt.setInt(1, application.getId());
			pstmt.setInt(2, application.getJob().getId());
			pstmt.setInt(3, application.getSeeker().getId());
			pstmt.setDate(4, application.getDate());
			
			
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new EmployeeExe("CONNECTION NOT CLOSED");
			}
		}
		
	
		return null;
	}

	
}
