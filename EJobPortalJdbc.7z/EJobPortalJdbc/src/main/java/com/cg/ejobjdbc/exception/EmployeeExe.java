package com.cg.ejobjdbc.exception;

public class EmployeeExe extends RuntimeException {

	public EmployeeExe()
	{
		super();
	}
	

	public EmployeeExe (String msg)
	{
		super(msg);
	}

}
