package com.cg.ejobjdbc.service;

import java.util.List;

import com.cg.ejobjdbc.dao.IJobDao;
import com.cg.ejobjdbc.dao.IJobDaoImpl;
import com.cg.ejobjdbc.dao.IJobSeekerDaoImpl;
import com.cg.ejobjdbc.dto.Job;


public class IJobServiceImpl implements IJobService {
	IJobDao jobDao;
	public IJobServiceImpl() {
		jobDao = new IJobDaoImpl();
	}
	public Job addJob(Job job) {
		// TODO Auto-generated method stub
		return jobDao.save(job);
	}
	public List<Job> searchByJobDescription(String description) {
		// TODO Auto-generated method stub
		return jobDao.findByDescription(description);
	}
	public List<Job> searchByJobCity(String city) {
		// TODO Auto-generated method stub
		return jobDao.findByCity(city);
	}
	public Job searchByJobId(int id) {
		// TODO Auto-generated method stub
		return jobDao.findById(id);
	}
	
}
