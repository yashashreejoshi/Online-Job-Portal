package com.cg.ejobjdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.cg.ejobjdbc.dto.Job;
import com.cg.ejobjdbc.dto.JobProvider;
import com.cg.ejobjdbc.exception.EmployeeExe;
import com.cg.ejobjdbc.util.DbUtil;

public class IJobDaoImpl implements IJobDao {

	public Job save(Job job) {
			Connection con = DbUtil.getConnection();
			String query_insert="INSERT INTO job VALUES(?,?,?,?,?,?)";
			PreparedStatement pstmt=null;
			try {
				pstmt = con.prepareStatement(query_insert);
				pstmt.setInt(1, job.getId());
				pstmt.setString(2, job.getDescription());
				pstmt.setInt(3, job.getVacancies());
				pstmt.setBigDecimal(4, job.getSalary());
				pstmt.setString(5, job.getCity());
				System.out.println(job.getCity());
				pstmt.setInt(6, job.getProvider().getId());
				
				
				pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			finally {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					throw new EmployeeExe("CONNECTION NOT CLOSED");
				}
			}
			
			return null;
	}

	public List<Job> findByDescription(String description) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Job> findByCity(String city) {
		// TODO Auto-generated method stub
		return null;
	}

	public Job findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
