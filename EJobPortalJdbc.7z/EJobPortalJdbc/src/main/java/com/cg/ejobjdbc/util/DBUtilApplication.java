package com.cg.ejobjdbc.util;

import java.util.ArrayList;
import java.util.List;

import com.cg.ejobjdbc.dto.JobApplication;

public class DBUtilApplication {
	public static JobApplication applications = new JobApplication();
}
