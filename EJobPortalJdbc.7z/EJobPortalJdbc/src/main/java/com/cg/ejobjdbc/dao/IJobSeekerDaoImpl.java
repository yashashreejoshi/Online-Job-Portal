package com.cg.ejobjdbc.dao;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.ejobjdbc.dto.JobProvider;
import com.cg.ejobjdbc.dto.JobSeeker;
import com.cg.ejobjdbc.exception.EmployeeExe;
import com.cg.ejobjdbc.util.DbUtil;

public class IJobSeekerDaoImpl implements IJobSeekerDao {

	public JobSeeker save(JobSeeker seeker) {
		Connection con = DbUtil.getConnection();
		String query_insert="INSERT INTO jobseeker VALUES(?,?,?,?,?,?)";
		PreparedStatement pstmt=null;
		try {
			
			pstmt = con.prepareStatement(query_insert);
			pstmt.setInt(1, seeker.getId());
			pstmt.setString(2, seeker.getName());
			pstmt.setString(3, seeker.getEmail());
			pstmt.setString(4,seeker.getContact().toString());
			pstmt.setString(5, seeker.getQualification());
			pstmt.setString(6, seeker.getCity());
			
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new EmployeeExe("CONNECTION NOT CLOSED");
			}
		}
		
		return null;
	}

	public JobSeeker findById(int id) {
		Connection con = DbUtil.getConnection();
		String query_insert="SELECT * FROM jobseeker WHERE seeker_id=?";
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		JobSeeker p = new JobSeeker();
		try{
			
			pstmt = con.prepareStatement(query_insert);
			pstmt.setInt(1, id);
			
			rs = pstmt.executeQuery();
			rs.next();
			p.setId(rs.getInt("seeker_id"));
			p.setName(rs.getString("name"));
			p.setEmail(rs.getString("email"));
			p.setContact(new BigInteger(rs.getString("contact")));
			p.setQualification(rs.getString("qualification"));
			p.setCity(rs.getString("city"));
			
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return p;
	}

}
