package com.cg.ejobjdbc.dao;

import java.sql.Connection;
import com.cg.ejobjdbc.util.DbUtil;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.ejobjdbc.dto.JobProvider;
import com.cg.ejobjdbc.dto.JobSeeker;
import com.cg.ejobjdbc.exception.EmployeeExe;

public class IJobProviderDaoImpl implements IJobProviderDao {

	
	public JobProvider save(JobProvider provider) {
		Connection con = DbUtil.getConnection();
		String query_insert="INSERT INTO jobprovider VALUES(?,?,?)";
		PreparedStatement pstmt=null;
		try {
			
			pstmt = con.prepareStatement(query_insert);
			pstmt.setInt(1, provider.getId());
			pstmt.setString(2, provider.getName());
			pstmt.setString(3, provider.getEmail());
			
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new EmployeeExe("CONNECTION NOT CLOSED");
			}
		}
		
		return null;
	}

	public JobProvider findById(int id) {
		Connection con = DbUtil.getConnection();
		String query_insert="SELECT provider_id,name,email FROM jobprovider WHERE provider_id=?";
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		JobProvider p = new JobProvider();
		try{
			
			pstmt = con.prepareStatement(query_insert);
			pstmt.setInt(1, id);
			
			rs = pstmt.executeQuery();
			rs.next();
			p.setId(rs.getInt("provider_id"));
			p.setName(rs.getString("name"));
			p.setEmail(rs.getString("email"));
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return p;
	}

}
