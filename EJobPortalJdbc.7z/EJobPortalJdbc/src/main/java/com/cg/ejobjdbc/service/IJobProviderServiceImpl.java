package com.cg.ejobjdbc.service;

import com.cg.ejobjdbc.dao.IJobProviderDao;
import com.cg.ejobjdbc.dao.IJobProviderDaoImpl;
import com.cg.ejobjdbc.dto.JobProvider;


public class IJobProviderServiceImpl implements IJobProviderService {

IJobProviderDao providerDao;
	
	public IJobProviderServiceImpl() {
		providerDao = new IJobProviderDaoImpl();
	}

	public JobProvider addProvider(JobProvider provider) {
		// TODO Auto-generated method stub
		return providerDao.save(provider);
	}

	public JobProvider searchByProviderId(int id) {
		// TODO Auto-generated method stub
		return providerDao.findById(id);
	}

}
