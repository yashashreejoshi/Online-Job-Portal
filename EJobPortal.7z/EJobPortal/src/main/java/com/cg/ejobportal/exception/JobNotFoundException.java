package com.cg.ejobportal.exception;

public class JobNotFoundException extends RuntimeException{

	public JobNotFoundException() { }
	public JobNotFoundException(String msg) {
		super(msg);
	}
	
}
