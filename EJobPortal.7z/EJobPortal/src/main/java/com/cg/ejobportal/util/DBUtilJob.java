package com.cg.ejobportal.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.ejobportal.dto.Job;

public class DBUtilJob {
	public static List<Job> jobs = new ArrayList<Job>(); 
	
	
}
