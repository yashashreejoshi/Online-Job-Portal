package com.cg.ejobportal.exception;

public class ProviderNotFoundException extends RuntimeException {
	public ProviderNotFoundException() { }
	public ProviderNotFoundException(String msg) {
		super(msg);
	}
}
