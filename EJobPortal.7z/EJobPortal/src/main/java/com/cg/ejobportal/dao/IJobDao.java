package com.cg.ejobportal.dao;

import java.util.List;

import com.cg.ejobportal.dto.Job;

public interface IJobDao {
	public Job save(Job job);
	public List<Job> findByDescription(String description);
	public List<Job> findByCity(String city);
	public Job findById(int id);
	public List<Job> show();

}
