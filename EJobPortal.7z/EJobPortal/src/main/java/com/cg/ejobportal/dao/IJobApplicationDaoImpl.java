package com.cg.ejobportal.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobApplication;
import com.cg.ejobportal.dto.JobSeeker;
import com.cg.ejobportal.util.DBUtilApplication;
import com.cg.ejobportal.util.DBUtilJob;
import com.cg.ejobportal.util.DBUtilSeeker;

public class IJobApplicationDaoImpl implements IJobApplicationDao {

	public List<JobApplication> save(JobApplication application) {
		DBUtilApplication.applications.add(application);
		return DBUtilApplication.applications;
	}

	public List<JobApplication> findById(int id) {
		return null;
	}

}
