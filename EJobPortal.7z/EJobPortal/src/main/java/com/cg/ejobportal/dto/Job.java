package com.cg.ejobportal.dto;

import java.math.BigDecimal;

public class Job {
	public Job() {
		
	}
	public Job(int id, String description, int vacancies, BigDecimal salary, String city, JobProvider provider) {
		super();
		this.id = id;
		this.description = description;
		this.vacancies = vacancies;
		this.salary = salary;
		this.city = city;
		this.provider = provider;
	}
	private int id;
	private String description;
	private int vacancies;
	private BigDecimal salary;
	private String city;
	private JobProvider provider;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getVacancies() {
		return vacancies;
	}
	public void setVacancies(int vacancies) {
		this.vacancies = vacancies;
	}
	public BigDecimal getSalary() {
		return salary;
	}
	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public JobProvider getProvider() {
		return provider;
	}
	public void setProvider(JobProvider provider) {
		this.provider = provider;
	}
	@Override
	public String toString() {
		return "Job [id=" + id + ", description=" + description + ", vacancies=" + vacancies + ", salary=" + salary
				+ ", city=" + city + ", provider=" + provider + "]";
	}
	
}
