package com.cg.ejobportal.service;

import com.cg.ejobportal.dao.IJobProviderDao;
import com.cg.ejobportal.dao.IJobProviderDaoImpl;
import com.cg.ejobportal.dto.JobProvider;

public class IJobProviderServiceImpl implements IJobProviderService{
	IJobProviderDao providerDao;
	
	public IJobProviderServiceImpl() {
		providerDao = new IJobProviderDaoImpl();
	}

	public JobProvider addProvider(JobProvider provider) {
		// TODO Auto-generated method stub
		return providerDao.save(provider);
	}

	public JobProvider searchByProviderId(int id) {
		// TODO Auto-generated method stub
		return providerDao.findById(id);
	}
	

}
