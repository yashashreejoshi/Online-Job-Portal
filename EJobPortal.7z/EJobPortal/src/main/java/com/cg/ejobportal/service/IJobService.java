package com.cg.ejobportal.service;

import java.util.List;

import com.cg.ejobportal.dto.Job;

public interface IJobService {
	public Job addJob(Job job);
	public List<Job> searchByJobDescription(String description);
	public List<Job> searchByJobCity(String city);
	public Job searchByJobId(int id);
}
