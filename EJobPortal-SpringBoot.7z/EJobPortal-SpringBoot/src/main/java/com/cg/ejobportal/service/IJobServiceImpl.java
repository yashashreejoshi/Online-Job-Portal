package com.cg.ejobportal.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ejobportal.dao.IJobDao;

import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.exception.JobIdNotFoundException;
import com.cg.ejobportal.exception.JobNotFoundException;

/*This class is a implementation of IJobService interface.
*
* Last Modified 14/05/2019  07.30 p.m.
* Author: Yashashree Joshi
*/
@Service
@Transactional
public class IJobServiceImpl implements IJobService{
	@Autowired
	IJobDao jobDao;
	static int jobId=100;
	
	static final Logger logger = Logger.getLogger(IJobServiceImpl.class); 
	
	/*This method is a implementation of IJobService interface method.
	 * It includes saving of jobs.
	 * 
	 * @param args Job job. 
	 * @return Job.
	 * 
	 * Last Modified 25/05/2019  05.00 p.m.
	 * @Author: Yashashree Joshi
	 */
	public Job addJob(Job job) {
		PropertyConfigurator.configure("D:\\Training_New\\EJobPortal-SpringBoot\\src\\main\\resources\\log4j.properties");
		job.setId(jobId);
		jobId++;
		logger.info("Saving Jobs");
		return jobDao.save(job);
	}
	

	/*This method is a implementation of IJobService interface method.
	 * It includes searching of jobs by description.
	 * 
	 * @param args String description. 
	 * @return List<Job>.
	 * 
	 *Last Modified 25/05/2019  05.00 p.m.
	 * @Author: Yashashree Joshi
	 */
	public List<Job> searchByJobDescription(String description) {
		PropertyConfigurator.configure("D:\\Training_New\\EJobPortal-SpringBoot\\src\\main\\resources\\log4j.properties");
		List<Job> storeJobs = jobDao.findByDescription(description);
		if(storeJobs.isEmpty())
			throw new JobNotFoundException("Jobs you are searching are not available");
		logger.info("Searching Jobs By Job Description");
		return jobDao.findByDescription(description);
		
	}
	
	/*This method is a implementation of IJobService interface method.
	 * It includes searching of jobs by city.
	 * 
	 * @param args String city. 
	 * @return List<Job>.
	 * 
	Last Modified 25/05/2019  05.00 p.m.
	 * @Author: Yashashree Joshi
	 */
	public List<Job> searchByJobCity(String city) {
		PropertyConfigurator.configure("D:\\Training_New\\EJobPortal-SpringBoot\\src\\main\\resources\\log4j.properties");
		List<Job> storeJobs = jobDao.findByCity(city);
		System.out.println(storeJobs);
		if(storeJobs.isEmpty())
			throw new JobNotFoundException("Jobs you are searching are not available");
		logger.info("Searching Jobs By Job City");
		return jobDao.findByCity(city);
	}
	
	/*This method is a implementation of IJobService interface method.
	 * It includes searching of jobs by id.
	 * 
	 * @param args int id. 
	 * @return Job.
	 * 
	Last Modified 25/05/2019  05.00 p.m.
	 * @Author: Yashashree Joshi
	 */

	public Job searchByJobId(int id) {
		PropertyConfigurator.configure("D:\\Training_New\\EJobPortal-SpringBoot\\src\\main\\resources\\log4j.properties");
		Job job=jobDao.findByid(id);
		if(job==null)
			throw new JobIdNotFoundException("job id not found");
		logger.info("Searching Job By Job Id");
		return job;
	}
}
