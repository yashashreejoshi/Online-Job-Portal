package com.cg.ejobportal.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ejobportal.dto.JobProvider;



public interface IJobProviderDao extends JpaRepository<JobProvider, Integer> {

	JobProvider findByid(int id);
}
