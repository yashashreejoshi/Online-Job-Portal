package com.cg.ejobportal.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ejobportal.dto.JobApplication;

public interface IJobApplicationDao extends JpaRepository<JobApplication, Integer> {

	
}
