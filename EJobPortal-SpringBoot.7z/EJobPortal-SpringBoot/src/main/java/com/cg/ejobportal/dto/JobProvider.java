package com.cg.ejobportal.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/*
 * This is bean class for JobProvider it includes int id, Sting name  String email.
 * Constructor,getter setter ,toString is defined
 *  Last Modified 14/05/2019  07.30 p.m.
 *  @Author: Yashashree Joshi
 * */ 
@Entity
@Table(name="job_provider")
public class JobProvider {
	public JobProvider() {
		
	}
	public JobProvider(Integer id, String name, String email) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
	}
	@Id
	@Column(name="provider_id")
	private Integer id;
	private String name;
	private String email;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "JobProvider [id=" + id + ", name=" + name + ", email=" + email + "]";
	}

}
