package com.cg.ejobportal.exception;

public class ProviderIdNotFoundException extends RuntimeException {
	public ProviderIdNotFoundException() { }
	public ProviderIdNotFoundException(String msg) {
		super(msg);
	}
}
