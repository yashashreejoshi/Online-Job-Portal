package com.cg.ejobportal.service;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ejobportal.dao.IJobApplicationDao;

import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobApplication;
import com.cg.ejobportal.dto.JobSeeker;
/*This class is a implementation of IJobApplication service interface.
 * It includes saving of job application.
 *
 *
 * Last Modified 06/05/2019  07.30 a.m.
 * Author: Yashashree Joshi
 */
@Service
@Transactional
public class IJobApplicationServiceImpl implements IJobApplicationService {
	@Autowired
	IJobApplicationDao applicationDao;
	static int applicationId=10;
	static final Logger logger = Logger.getLogger(IJobApplicationServiceImpl.class); 
	/*This method is used to save jobApplication.
	 *
	 * @param args JobApplication application. 
	 * @return List<JobApplication>.
	 * 
	 * Last Modified 14/05/2019  07.30 p.m.
	 * Author: Yashashree Joshi
	 */
	public JobApplication applyJob(JobApplication application) {
		PropertyConfigurator.configure("D:\\Training_New\\EJobPortal-SpringBoot\\src\\main\\resources\\log4j.properties");
		application.setId(applicationId);
		applicationId++;
		logger.info("JobApplication Saved");
		return applicationDao.save(application);
	}

}
