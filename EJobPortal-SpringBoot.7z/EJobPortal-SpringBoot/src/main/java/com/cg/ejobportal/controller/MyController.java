package com.cg.ejobportal.controller;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobApplication;
import com.cg.ejobportal.dto.JobProvider;
import com.cg.ejobportal.dto.JobSeeker;
import com.cg.ejobportal.exception.JobIdNotFoundException;
import com.cg.ejobportal.exception.JobNotFoundException;
import com.cg.ejobportal.exception.ProviderIdNotFoundException;

import com.cg.ejobportal.exception.SeekerNotFoundException;
import com.cg.ejobportal.service.IJobApplicationService;
import com.cg.ejobportal.service.IJobProviderService;
import com.cg.ejobportal.service.IJobSeekerService;
import com.cg.ejobportal.service.IJobService;

@RestController
@RequestMapping("/jobportal")
public class MyController {
	
	@Autowired
	IJobProviderService providerService;
	@Autowired
	IJobSeekerService seekerService;
	@Autowired
	IJobService jobService;
	@Autowired
	IJobApplicationService applicationService;
	
	@RequestMapping(value="/addProvider", method=RequestMethod.POST)
	public ResponseEntity<JobProvider> addProvider(@ModelAttribute JobProvider provider) {
		JobProvider prov = providerService.addProvider(provider);
		
		 return new ResponseEntity<JobProvider>(prov,HttpStatus.OK);
	}
	
	@RequestMapping(value="/addJob", method=RequestMethod.POST)
	public ResponseEntity<Job> addJob(@ModelAttribute Job job) {
		JobProvider provider = providerService.searchByProviderId(job.getProvider().getId());
		job.setProvider(provider);
		System.out.println(provider);
		if(provider==null) {
			return new ResponseEntity("Provider Id Not Present",HttpStatus.NOT_FOUND);
		}
		Job jobs = jobService.addJob(job);
		
		 return new ResponseEntity<Job>(jobs,HttpStatus.OK);
	}
	
	@RequestMapping(value="/addSeeker", method=RequestMethod.POST)
	public ResponseEntity<JobSeeker> addSeeker(@ModelAttribute JobSeeker seeker) {
		JobSeeker seek = seekerService.addSeeker(seeker);
		if(seek==null) {
			return new ResponseEntity("Seeker Not Added",HttpStatus.NOT_FOUND);
		}
		 return new ResponseEntity<JobSeeker>(seek,HttpStatus.OK);
	}
	
	@RequestMapping(value="/addApplication", method=RequestMethod.POST)
	public ResponseEntity<JobApplication> addApplication(@ModelAttribute JobApplication application) {
		application.setDate(new Timestamp(System.currentTimeMillis()));
		
		JobSeeker seeker = seekerService.searchBySeekerId(application.getSeeker().getId());
		if(seeker == null) {
			return new ResponseEntity("Seeker Not Found",HttpStatus.NOT_FOUND);
		}
		
		Job job = jobService.searchByJobId(application.getJob().getId());
		if(job == null) {
			return new ResponseEntity("Job Not Found",HttpStatus.NOT_FOUND);
		}
		JobApplication apply = applicationService.applyJob(application);
		if(apply==null) {
			return new ResponseEntity("JobApplication Not Added",HttpStatus.NOT_FOUND);
		}
		 return new ResponseEntity<JobApplication>(apply,HttpStatus.OK);
	}
	
	@RequestMapping(value="/searchDes", method=RequestMethod.POST)
    public ResponseEntity<List<Job>> showAllJobByDescription(@ModelAttribute Job job) {
   	 List<Job> myList= jobService.searchByJobDescription(job.getDescription());
   	 if(myList.isEmpty()) {
   		 return new ResponseEntity("No Jobs to Show",HttpStatus.NOT_FOUND);
   	 }
   	 return new ResponseEntity<List<Job>>(myList,HttpStatus.OK);
    }
	
	@RequestMapping(value="/searchCity", method=RequestMethod.POST)
    public ResponseEntity<List<Job>> showAllJobByCity(@ModelAttribute Job job) {
   	 List<Job> myList= jobService.searchByJobCity(job.getCity());
   	 if(myList.isEmpty()) {
   		 return new ResponseEntity("No Jobs to Show",HttpStatus.NOT_FOUND);
   	 }
   	 return new ResponseEntity<List<Job>>(myList,HttpStatus.OK);
    }
	
	@ExceptionHandler({JobNotFoundException.class})
	public ResponseEntity handleJobException(JobNotFoundException be) {

		return new ResponseEntity(be.getMessage(),HttpStatus.NOT_FOUND);

	}  
	
	@ExceptionHandler({SeekerNotFoundException.class})
	public ResponseEntity handleJobException(SeekerNotFoundException be) {

		return new ResponseEntity(be.getMessage(),HttpStatus.NOT_FOUND);

	}  
	
	@ExceptionHandler({JobIdNotFoundException.class})
	public ResponseEntity handleJobException(JobIdNotFoundException be) {

		return new ResponseEntity(be.getMessage(),HttpStatus.NOT_FOUND);

	}  
	
	@ExceptionHandler({ProviderIdNotFoundException.class})
	public ResponseEntity handleJobException(ProviderIdNotFoundException be) {

		return new ResponseEntity(be.getMessage(),HttpStatus.NOT_FOUND);

	}  
	
	
	  
		
		  
		 

	
}
