package com.cg.ejobportal.dto;




import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/*
 * This is bean class for JobApplication it includes int id,  JOb job, JobSeeker seeker, and  Date date.
 * Constructor,getter setter ,toString is defined
 *  Last Modified 14/05/2019  07.30 p.m.
 *  @Author: Yashashree Joshi
 * */ 


@Entity
@Table(name="jobapplication")
public class JobApplication {
	public JobApplication() {
		
	}
	
	public JobApplication(Integer id, Timestamp date, JobSeeker seeker, Job job) {
		super();
		this.id = id;
		this.date = date;
		this.seeker = seeker;
		this.job = job;
	}
	
	@Id
	@Column(name="application_id")
	private Integer id;
	private Timestamp date;
	@ManyToOne
	@JoinColumn(name="seeker_id")
	private JobSeeker seeker;
	@OneToOne
	@JoinColumn(name="job_id")
	private Job job;
	
	public Timestamp getDate() {
		return date;
	}
	public void setDate(Timestamp date) {
		this.date = date;
	}
	public JobSeeker getSeeker() {
		return seeker;
	}
	public void setSeeker(JobSeeker seeker) {
		this.seeker = seeker;
	}
	public Job getJob() {
		return job;
	}
	public void setJob(Job job) {
		this.job = job;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "JobApplication [id=" + id + ", date=" + date + ", seeker=" + seeker + ", job=" + job + "]";
	}

}
