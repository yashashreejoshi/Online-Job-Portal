package com.cg.ejobportal.service;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ejobportal.dao.IJobProviderDao;

import com.cg.ejobportal.dto.JobProvider;
import com.cg.ejobportal.exception.ProviderIdNotFoundException;


@Service
@Transactional
public class IJobProviderServiceImpl implements IJobProviderService{
	@Autowired
	IJobProviderDao providerDao;
	static int providerId=200;
	static final Logger logger = Logger.getLogger(IJobProviderServiceImpl.class); 
	/*This method is a implementation of IJobProvider service interface method.
	 * It includes saving of job provider.
	 * 
	 * @param args JobProvider provider
	 * @return JobProvider
	 * 
	 * Last Modified 25/05/2019  05.00 p.m.
	 * @Author: Yashashree Joshi
	 */
	public JobProvider addProvider(JobProvider provider) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("D:\\Training_New\\EJobPortal-SpringBoot\\src\\main\\resources\\log4j.properties");
		provider.setId(providerId);
		providerId++;
		logger.info("Provider Saved");
		return providerDao.save(provider);
	}

	/*This method is a implementation of IJobProvider Service interface method.
 	 * It includes searching of job provider by id.
 	 * 
 	 * @param args int id. 
 	 * @return JobProvider.
 	 * 
 	 * Last Modified 25/05/2019  05.00 p.m.
	 * @Author: Yashashree Joshi
 	 */
	public JobProvider searchByProviderId(int id) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("D:\\Training_New\\EJobPortal-SpringBoot\\src\\main\\resources\\log4j.properties");
		JobProvider provider = providerDao.findByid(id);
		if(provider==null)
			throw new ProviderIdNotFoundException("provider not found");
		logger.info("Searching Provider By Id");
		return provider;
		
	}
	

}
