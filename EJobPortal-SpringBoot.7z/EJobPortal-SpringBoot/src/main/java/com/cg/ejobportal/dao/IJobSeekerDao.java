package com.cg.ejobportal.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ejobportal.dto.JobProvider;
import com.cg.ejobportal.dto.JobSeeker;

public interface IJobSeekerDao extends JpaRepository<JobSeeker, Integer> {

	JobSeeker findByid(int id);
}
