package com.cg.ejobportal.service;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ejobportal.dao.IJobSeekerDao;

import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobSeeker;
import com.cg.ejobportal.exception.JobIdNotFoundException;
import com.cg.ejobportal.exception.SeekerNotFoundException;

/*This class is a implementation of IJobSeeker service interface.
*
*
*Last Modified 25/05/2019  05.00 p.m.
* @Author: Yashashree Joshi
*/
@Service
@Transactional//this will create service bean
public class IJobSeekerServiceImpl implements IJobSeekerService{
	@Autowired				
	IJobSeekerDao seekerDao;
	static int seekerId=500;
	
	static final Logger logger = Logger.getLogger(IJobSeekerServiceImpl.class); 

	/*This method is a implementation of IJobSeeker service interface method.
	 * It includes saving of job seeker.
	 * 
	 * @param args JobSeeker seeker. 
	 * @return JobSeeker.
	 * 
	 * Last Modified 25/05/2019  05.00 p.m.
	 * @Author: Yashashree Joshi
	 */
	public JobSeeker addSeeker(JobSeeker seeker) {
		PropertyConfigurator.configure("D:\\Training_New\\EJobPortal-SpringBoot\\src\\main\\resources\\log4j.properties");
		// TODO Auto-generated method stub
		seeker.setId(seekerId);
		seekerId++;
		logger.info("Seeker Saved");
		return seekerDao.save(seeker);
	}


	/*This method is a implementation of IJobSeeker Service interface method.
	 * It includes searching of jobs by id.
	 * 
	 * @param args int id. 
	 * @return Job.
	 * 
	 *Last Modified 25/05/2019  05.00 p.m.
	 * @Author: Yashashree Joshi
	 */
	public JobSeeker searchBySeekerId(int id) {
		PropertyConfigurator.configure("D:\\Training_New\\EJobPortal-SpringBoot\\src\\main\\resources\\log4j.properties");
		// TODO Auto-generated method stub
		JobSeeker seeker=seekerDao.findByid(id);
		if(seeker==null)
			throw new SeekerNotFoundException("seeker not found");
		logger.info("Searching Seeker By Id");
		return seeker;
	
	}

}
