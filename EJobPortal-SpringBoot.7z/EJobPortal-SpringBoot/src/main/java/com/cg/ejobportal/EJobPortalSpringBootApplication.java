package com.cg.ejobportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.cg.ejobportal.dto.Job;

@SpringBootApplication
@ComponentScan("com.cg.ejobportal")
public class EJobPortalSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(EJobPortalSpringBootApplication.class, args);
	}
	
	

}
