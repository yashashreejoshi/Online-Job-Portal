package com.cg.ejobportal.dto;

import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

 
/*
 * This is bean class for Job it includes int id, string description int vacancies, BigInteger salary, String city, JobProvider provider details
 * Constructor,getter setter ,toString is defined
 *  Last Modified 14/05/2019  07.30 p.m.
 *  @Author: Yashashree Joshi
 * */ 
 

@Entity
@Table(name="job")
public class Job {
	public Job() {
		
	}
	public Job(Integer id, String description, Integer vacancies, BigDecimal salary, String city, JobProvider provider) {
		super();
		this.id = id;
		this.description = description;
		this.vacancies = vacancies;
		this.salary = salary;
		this.city = city;
		this.provider = provider;
	}
	@Id
	@Column(name="job_id")
	
	private Integer id;
	
	private String description;

	private Integer vacancies;
	
	private BigDecimal salary;
	
	private String city;
	@ManyToOne(cascade =CascadeType.ALL)
	@JoinColumn(name="provider_id")

	private JobProvider provider;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getVacancies() {
		return vacancies;
	}
	public void setVacancies(Integer vacancies) {
		this.vacancies = vacancies;
	}
	public BigDecimal getSalary() {
		return salary;
	}
	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public JobProvider getProvider() {
		return provider;
	}
	public void setProvider(JobProvider provider) {
		this.provider = provider;
	}
	@Override
	public String toString() {
		return "Job [id=" + id + ", description=" + description + ", vacancies=" + vacancies + ", salary=" + salary
				+ ", city=" + city + ", provider=" + provider + "]";
	}
	
}
