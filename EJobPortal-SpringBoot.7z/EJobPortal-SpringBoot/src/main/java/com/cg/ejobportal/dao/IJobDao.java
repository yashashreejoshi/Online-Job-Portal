package com.cg.ejobportal.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobProvider;

public interface IJobDao extends JpaRepository<Job, Integer>{
	Job findByid(int id);
	List<Job> findByDescription(String description);
	List<Job> findByCity(String city);
}
