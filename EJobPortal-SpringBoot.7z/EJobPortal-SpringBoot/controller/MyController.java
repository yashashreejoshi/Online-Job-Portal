package com.cg.ejobportal.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobApplication;
import com.cg.ejobportal.dto.JobProvider;
import com.cg.ejobportal.dto.JobSeeker;
import com.cg.ejobportal.exception.JobIdNotFoundException;
import com.cg.ejobportal.exception.JobNotFoundException;
import com.cg.ejobportal.exception.ProviderIdNotFoundException;

import com.cg.ejobportal.exception.SeekerNotFoundException;
import com.cg.ejobportal.service.IJobApplicationService;
import com.cg.ejobportal.service.IJobProviderService;
import com.cg.ejobportal.service.IJobSeekerService;
import com.cg.ejobportal.service.IJobService;

@Controller
public class MyController {
	
	@Autowired
	IJobProviderService providerService;
	@Autowired
	IJobSeekerService seekerService;
	@Autowired
	IJobService jobService;
	@Autowired
	IJobApplicationService applicationService;
	
	@GetMapping("menu")	
	public String loginPage() {
		return "mainmenu";
		
	}
	
	@GetMapping("addProv")
	public ModelAndView getProvider(@ModelAttribute("prov") JobProvider provider) {
	
		return new ModelAndView("addProvider");
	}
	
	@PostMapping("addProvider")
	public ModelAndView addProvider(@ModelAttribute("prov") JobProvider provider) {
		JobProvider provide=providerService.addProvider(provider);
		return new ModelAndView("success", "key6", provide);
		
	}
	@GetMapping("addJob")
	public ModelAndView getProvider(@ModelAttribute("job") Job job) {
	
		return new ModelAndView("addJob");
	}
	
	@PostMapping("addJob")
	public ModelAndView addProvider(@ModelAttribute("job") Job job) {
		Job jobs =jobService.addJob(job);
		return new ModelAndView("mainmenu", "key5", jobs);
		
	}
	
	
	@GetMapping("addSeek")
	public ModelAndView getSeeker(@ModelAttribute("seek") JobSeeker seeker) {
	
		return new ModelAndView("addSeeker");
	}
	
	@PostMapping("addSeeker")
	public ModelAndView addSeeker(@ModelAttribute("seek") JobSeeker seeker) {
		JobSeeker seek=seekerService.addSeeker(seeker);
		return new ModelAndView("mainmenu", "key4", seek);
		
	}
	
	@GetMapping("searchByDes")
	public ModelAndView getSearchByDescription(@ModelAttribute("job") Job job) {
	
		return new ModelAndView("search");
	}
	
	@PostMapping("searchByDes")
	public ModelAndView searchByDescription(@RequestParam("des") String description, Model model) {
		List<Job> job= jobService.searchByJobDescription(description);
		model.addAttribute("key3", job);
		return new ModelAndView("search");
		
	}
	
	@GetMapping("searchByCity")
	public ModelAndView getSearchByCity(@ModelAttribute("job") Job job) {
	
		return new ModelAndView("searchByCity");
	}
	
	@PostMapping("searchByCity")
	public ModelAndView searchByCity(@RequestParam("city") String city, Model model) {
		List<Job> job= jobService.searchByJobCity(city);
		model.addAttribute("key2", job);
		return new ModelAndView("searchByCity");
		
	}
	
	@GetMapping("apply")
	public ModelAndView getApply(@ModelAttribute("apply") JobApplication application) {
	
		return new ModelAndView("applyJob");
	}
	
	@PostMapping("applyJob")
	public ModelAndView applyJob(@ModelAttribute("apply") JobApplication application) {
		JobApplication applied= applicationService.applyJob(application);
		//System.out.println(applied);
		return new ModelAndView("successApply","key",applied);
	
	}

		@ExceptionHandler({JobNotFoundException.class})
		public ModelAndView handlePlayerException(JobNotFoundException be) {

			ModelAndView model = new ModelAndView("error");

			model.addObject("errMsg1", be.getMessage());

			return model;

		}  
		
		@ExceptionHandler({SeekerNotFoundException.class})
		public ModelAndView handlePlayerException(SeekerNotFoundException be) {

			ModelAndView model = new ModelAndView("error");

			model.addObject("errMsg2", be.getMessage());

			return model;

		}  
		
		@ExceptionHandler({JobIdNotFoundException.class})
		public ModelAndView handlePlayerException(JobIdNotFoundException be) {

			ModelAndView model = new ModelAndView("error");

			model.addObject("errMsg3", be.getMessage());

			return model;

		}  
		
		@ExceptionHandler({ProviderIdNotFoundException.class})
		public ModelAndView handlePlayerException(ProviderIdNotFoundException be) {

			ModelAndView model = new ModelAndView("errorProvider");

			model.addObject("errMsg4", be.getMessage());

			return model;

		}  
		
		
		  
		 

	
}
